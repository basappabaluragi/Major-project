package com.example.smartvotingapp;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class AdminHomeFragment extends Fragment implements NewsManager.NewsUpdateListener {

    private LinearLayout newsContainer;
    private NewsManager newsManager;

    public AdminHomeFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        try {
            View view = inflater.inflate(R.layout.fragment_admin_home, container, false);

            newsManager = new NewsManager(getContext());
            newsManager.addListener(this); // Add real-time listener

            newsContainer = view.findViewById(R.id.newsContainer);
            Button btnAddNews = view.findViewById(R.id.btnAddNews);
            Button btnViewFeedback = view.findViewById(R.id.btnViewFeedback);

            btnAddNews.setOnClickListener(v -> showAddEditDialog(null));

            btnViewFeedback.setOnClickListener(v -> {
                try {
                    getParentFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, new AdminFeedbackFragment())
                            .addToBackStack(null)
                            .commit();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            loadNews();

            return view;
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Error loading home: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return new View(getContext());
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (newsManager != null) {
            newsManager.removeListener(this);
        }
    }

    @Override
    public void onNewsUpdated() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(this::loadNews);
        }
    }

    private void loadNews() {
        if (newsContainer == null)
            return;
        newsContainer.removeAllViews();
        List<News> newsList = newsManager.getAllNews();

        if (newsList.isEmpty()) {
            TextView emptyView = new TextView(getContext());
            emptyView.setText("No news added yet. Click 'Add News' to create one.");
            emptyView.setPadding(32, 32, 32, 32);
            emptyView.setTextSize(16);
            newsContainer.addView(emptyView);
            return;
        }

        for (News news : newsList) {
            View newsView = LayoutInflater.from(getContext()).inflate(R.layout.item_news_admin, newsContainer, false);

            TextView title = newsView.findViewById(R.id.tvTitle);
            TextView date = newsView.findViewById(R.id.tvDate);
            TextView desc = newsView.findViewById(R.id.tvDescription);
            android.widget.ImageView imgNews = newsView.findViewById(R.id.imgNews);
            Button btnEdit = newsView.findViewById(R.id.btnEdit);
            Button btnDelete = newsView.findViewById(R.id.btnDelete);

            title.setText(news.getTitle());
            date.setText(news.getDate());
            desc.setText(news.getDescription());

            if (news.getImageUrl() != null && !news.getImageUrl().isEmpty()) {
                imgNews.setVisibility(View.VISIBLE);
                try {
                    String url = news.getImageUrl();
                    if (url.startsWith("data:")) {
                        // Base64
                        String base64 = url.substring(url.indexOf(",") + 1);
                        byte[] decodedString = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                        android.graphics.Bitmap decodedByte = android.graphics.BitmapFactory
                                .decodeByteArray(decodedString, 0, decodedString.length);
                        imgNews.setImageBitmap(decodedByte);
                    } else {
                        new Thread(() -> {
                            try {
                                java.io.InputStream in = new java.net.URL(url).openStream();
                                android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeStream(in);
                                newsView.post(() -> imgNews.setImageBitmap(bmp));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }).start();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                imgNews.setVisibility(View.GONE);
            }

            btnEdit.setOnClickListener(v -> showAddEditDialog(news));
            btnDelete.setOnClickListener(v -> {
                new AlertDialog.Builder(getContext())
                        .setTitle("Delete News")
                        .setMessage("Are you sure you want to delete this news?")
                        .setPositiveButton("Delete", (dialog, which) -> {
                            newsManager.deleteNews(news.getId());
                            Toast.makeText(getContext(), "News deleted", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            });

            newsContainer.addView(newsView);
        }
    }

    private androidx.activity.result.ActivityResultLauncher<String> pickImageLauncher;
    private EditText currentImageUrlInput;
    private android.widget.ImageView currentImagePreview;
    private String tempBase64Image;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pickImageLauncher = registerForActivityResult(
                new androidx.activity.result.contract.ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        try {
                            // Convert to Base64
                            java.io.InputStream inputStream = getContext().getContentResolver().openInputStream(uri);
                            android.graphics.Bitmap originalBitmap = android.graphics.BitmapFactory
                                    .decodeStream(inputStream);

                            // Resize if too big (max 1200px width)
                            int width = originalBitmap.getWidth();
                            int height = originalBitmap.getHeight();
                            float maxSz = 1200f;
                            if (width > maxSz) {
                                float ratio = maxSz / width;
                                width = (int) maxSz;
                                height = (int) (height * ratio);
                                originalBitmap = android.graphics.Bitmap.createScaledBitmap(originalBitmap, width,
                                        height, true);
                            }

                            java.io.ByteArrayOutputStream byteArrayOutputStream = new java.io.ByteArrayOutputStream();
                            originalBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90,
                                    byteArrayOutputStream);
                            byte[] byteArray = byteArrayOutputStream.toByteArray();
                            String base64Image = "data:image/jpeg;base64,"
                                    + android.util.Base64.encodeToString(byteArray, android.util.Base64.NO_WRAP);

                            // Store internally, don't put in EditText
                            tempBase64Image = base64Image;

                            if (currentImageUrlInput != null) {
                                currentImageUrlInput.setText(""); // Clear URL input
                                currentImageUrlInput.setHint("Image selected from gallery");
                            }
                            if (currentImagePreview != null) {
                                currentImagePreview.setVisibility(View.VISIBLE);
                                currentImagePreview.setImageBitmap(originalBitmap);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(getContext(), "Failed to process image", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void showAddEditDialog(News news) {
        tempBase64Image = null; // Reset
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_news, null);
        builder.setView(view);
        builder.setTitle(news == null ? "Add News" : "Edit News");

        EditText etTitle = view.findViewById(R.id.etTitle);
        EditText etDescription = view.findViewById(R.id.etDescription);
        EditText etImageUrl = view.findViewById(R.id.etImageUrl);
        Button btnPickImage = view.findViewById(R.id.btnPickImage);
        android.widget.ImageView imgPreview = view.findViewById(R.id.imgPreview);

        // Save references for the callback
        currentImageUrlInput = etImageUrl;
        currentImagePreview = imgPreview;

        if (news != null) {
            etTitle.setText(news.getTitle());
            etDescription.setText(news.getDescription());

            if (news.getImageUrl() != null && !news.getImageUrl().isEmpty()) {
                String url = news.getImageUrl();
                if (url.startsWith("data:")) {
                    tempBase64Image = url;
                    etImageUrl.setHint("Stored image (Base64)");

                    // Show preview
                    try {
                        String base64 = url.substring(url.indexOf(",") + 1);
                        byte[] decodedString = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                        android.graphics.Bitmap decodedByte = android.graphics.BitmapFactory
                                .decodeByteArray(decodedString, 0, decodedString.length);
                        imgPreview.setVisibility(View.VISIBLE);
                        imgPreview.setImageBitmap(decodedByte);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    etImageUrl.setText(url);
                    // Load URL preview
                    new Thread(() -> {
                        try {
                            java.io.InputStream in = new java.net.URL(url).openStream();
                            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeStream(in);
                            imgPreview.post(() -> {
                                imgPreview.setVisibility(View.VISIBLE);
                                imgPreview.setImageBitmap(bmp);
                            });
                        } catch (Exception e) {
                        }
                    }).start();
                }
            }
        }

        btnPickImage.setOnClickListener(v -> pickImageLauncher.launch("image/*"));

        // If user manually types, clear tempBase64Image
        etImageUrl.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0)
                    tempBase64Image = null;
            }

            public void afterTextChanged(android.text.Editable s) {
            }
        });

        builder.setPositiveButton("Save", (dialog, which) -> {
            String title = etTitle.getText().toString().trim();
            String desc = etDescription.getText().toString().trim();
            String typedUrl = etImageUrl.getText().toString().trim();

            // Prioritize tempBase64Image if active, else typed URL
            String finalImageUrl = (tempBase64Image != null) ? tempBase64Image : typedUrl;

            if (title.isEmpty() || desc.isEmpty()) {
                Toast.makeText(getContext(), "Please fill title and description", Toast.LENGTH_SHORT).show();
                return;
            }

            String date = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
            long timestamp = System.currentTimeMillis();

            if (news == null) {
                // Add new
                News newNews = new News(UUID.randomUUID().toString(), title, desc, date, timestamp, finalImageUrl);
                newsManager.addNews(newNews);
                Toast.makeText(getContext(), "News added successfully", Toast.LENGTH_SHORT).show();
            } else {
                // Update existing
                News updatedNews = new News(news.getId(), title, desc, date, timestamp, finalImageUrl);
                newsManager.updateNews(updatedNews);
                Toast.makeText(getContext(), "News updated successfully", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}
