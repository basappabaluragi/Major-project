package com.example.smartvotingapp;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import java.util.List;

public class AdminUserListFragment extends Fragment implements UserManager.UserUpdateListener {

    private LinearLayout userContainer;
    private UserManager userManager;

    public AdminUserListFragment() {
    }

    private String adminScope;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        try {
            if (getArguments() != null) {
                adminScope = getArguments().getString("admin_scope");
            }

            View view = inflater.inflate(R.layout.fragment_admin_user_list, container, false);

            userManager = new UserManager(getContext());
            userManager.addListener(this); // Add real-time listener

            userContainer = view.findViewById(R.id.userContainer);
            Button btnAddUser = view.findViewById(R.id.btnAddUser);

            btnAddUser.setOnClickListener(v -> showAddUserDialog());

            loadUsers();

            return view;
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Error loading users: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return new View(getContext());
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (userManager != null) {
            userManager.removeListener(this);
        }
    }

    @Override
    public void onUsersUpdated() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(this::loadUsers);
        }
    }

    private void loadUsers() {
        if (userContainer == null)
            return;
        userContainer.removeAllViews();
        List<User> users = userManager.getAllUsers();

        // Count filtered users
        int visibleCount = 0;
        for (User user : users) {
            if (adminScope != null && !adminScope.isEmpty()) {
                if (user.getState() == null || !user.getState().equalsIgnoreCase(adminScope)) {
                    continue;
                }
            }
            if (user.isDeleted())
                continue;
            visibleCount++;
        }

        if (visibleCount == 0) {
            TextView empty = new TextView(getContext());
            if (adminScope != null && !adminScope.isEmpty()) {
                empty.setText("No users found in " + adminScope + " state.\nClick 'Add User' to create one.");
            } else {
                empty.setText("No users found.\nClick 'Add User' to create one.");
            }
            empty.setPadding(32, 32, 32, 32);
            empty.setTextSize(16);
            userContainer.addView(empty);
            return;
        }

        for (User user : users) {
            // FILTER: If admin has a scope, only show users from that state
            // FILTER: If admin has a scope, only show users from that state
            if (adminScope != null && !adminScope.isEmpty()) {
                if (user.getState() == null || !user.getState().equalsIgnoreCase(adminScope)) {
                    continue; // Skip users from other states
                }
            }

            // FILTER: Don't show deleted users
            if (user.isDeleted()) {
                continue;
            }

            View userView = LayoutInflater.from(getContext()).inflate(R.layout.item_user_admin, userContainer, false);

            TextView name = userView.findViewById(R.id.tvName);
            TextView aadhaar = userView.findViewById(R.id.tvAadhaar);
            Button btnEdit = userView.findViewById(R.id.btnEdit);
            Button btnDelete = userView.findViewById(R.id.btnDelete);

            name.setText(user.getName());
            aadhaar.setText("Aadhaar: " + user.getAadhaarId());

            btnEdit.setOnClickListener(v -> showEditUserDialog(user));

            // Only Super Admin can delete users
            if (adminScope == null || adminScope.isEmpty()) {
                btnDelete.setVisibility(View.VISIBLE);
                btnDelete.setOnClickListener(v -> {
                    new AlertDialog.Builder(getContext())
                            .setTitle("Delete User")
                            .setMessage("Are you sure you want to delete " + user.getName()
                                    + "?\nThey will no longer be able to login.")
                            .setPositiveButton("Delete", (dialog, which) -> {
                                userManager.deleteUser(user.getAadhaarId());
                                Toast.makeText(getContext(), "User deleted", Toast.LENGTH_SHORT).show();
                                loadUsers(); // Refresh list
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                });
            } else {
                btnDelete.setVisibility(View.GONE);
            }

            userContainer.addView(userView);
        }
    }

    private void showEditUserDialog(User user) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_edit_user, null);
        builder.setView(view);

        EditText etName = view.findViewById(R.id.etName);
        EditText etEmail = view.findViewById(R.id.etEmail);
        EditText etMobile = view.findViewById(R.id.etMobile);
        EditText etAddress = view.findViewById(R.id.etAddress);
        EditText etCity = view.findViewById(R.id.etCity);
        android.widget.Spinner spinnerState = view.findViewById(R.id.spinnerState);
        EditText etPincode = view.findViewById(R.id.etPincode);
        EditText etDob = view.findViewById(R.id.etDob);
        CheckBox cbEligible = view.findViewById(R.id.cbEligible);

        // Populate state spinner
        String[] states = new String[] { "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
                "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala",
                "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha",
                "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh",
                "Uttarakhand", "West Bengal", "Delhi" };
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, states);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerState.setAdapter(adapter);

        // Set existing values
        etName.setText(user.getName());
        etEmail.setText(user.getEmail());
        etMobile.setText(user.getMobile());
        etAddress.setText(user.getAddress());
        etCity.setText(user.getCity());
        etPincode.setText(user.getPincode());
        etDob.setText(user.getDob());
        cbEligible.setChecked(user.isEligible());

        // Set spinner selection
        if (user.getState() != null) {
            for (int i = 0; i < states.length; i++) {
                if (states[i].equalsIgnoreCase(user.getState())) {
                    spinnerState.setSelection(i);
                    break;
                }
            }
        }

        // LOCK STATE for State Admins
        if (adminScope != null && !adminScope.isEmpty()) {
            spinnerState.setEnabled(false); // Disable changing state
            // Ensure the spinner is set to the admin's scope (should match user's state
            // anyway due to filtering)
            for (int i = 0; i < states.length; i++) {
                if (states[i].equalsIgnoreCase(adminScope)) {
                    spinnerState.setSelection(i);
                    break;
                }
            }
        } else {
            spinnerState.setEnabled(true); // India Govt can change state
        }

        // DOB Picker
        etDob.setOnClickListener(v -> {
            java.util.Calendar c = java.util.Calendar.getInstance();
            int y = c.get(java.util.Calendar.YEAR);
            int m = c.get(java.util.Calendar.MONTH);
            int d = c.get(java.util.Calendar.DAY_OF_MONTH);
            try {
                String[] parts = user.getDob().split("-");
                if (parts.length == 3) {
                    y = Integer.parseInt(parts[0]);
                    m = Integer.parseInt(parts[1]) - 1;
                    d = Integer.parseInt(parts[2]);
                }
            } catch (Exception ignored) {
            }
            new android.app.DatePickerDialog(getContext(), (dp, year, month, day) -> {
                etDob.setText(year + "-" + String.format("%02d", (month + 1)) + "-" + String.format("%02d", day));
            }, y, m, d).show();
        });

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newName = etName.getText().toString().trim();
            String newEmail = etEmail.getText().toString().trim();
            String newMobile = etMobile.getText().toString().trim();
            String newAddress = etAddress.getText().toString().trim();
            String newCity = etCity.getText().toString().trim();
            String newState = spinnerState.getSelectedItem() != null ? spinnerState.getSelectedItem().toString() : "";
            String newPincode = etPincode.getText().toString().trim();
            String newDob = etDob.getText().toString().trim();
            boolean isEligible = cbEligible.isChecked();

            User updatedUser = new User(
                    user.getAadhaarId(),
                    newName,
                    newDob,
                    newEmail,
                    newMobile,
                    user.getPhoto(),
                    newAddress,
                    newCity,
                    newState,
                    newPincode,
                    isEligible);

            userManager.updateUser(updatedUser);
            loadUsers();
            Toast.makeText(getContext(), "User updated", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showAddUserDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_user, null);
        builder.setView(view);
        builder.setTitle("Add New User");

        EditText etAadhaar = view.findViewById(R.id.etAadhaar);
        EditText etName = view.findViewById(R.id.etName);
        EditText etDob = view.findViewById(R.id.etDob);
        EditText etEmail = view.findViewById(R.id.etEmail);
        EditText etMobile = view.findViewById(R.id.etMobile);
        EditText etAddress = view.findViewById(R.id.etAddress);
        EditText etCity = view.findViewById(R.id.etCity);
        android.widget.Spinner spinnerState = view.findViewById(R.id.spinnerState);
        EditText etPincode = view.findViewById(R.id.etPincode);
        CheckBox cbEligible = view.findViewById(R.id.cbEligible);

        // Populate state spinner
        String[] states = new String[] { "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
                "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala",
                "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha",
                "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh",
                "Uttarakhand", "West Bengal", "Delhi" };
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, states);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerState.setAdapter(adapter);

        // AUTO-SELECT & LOCK STATE for State Admins
        if (adminScope != null && !adminScope.isEmpty()) {
            for (int i = 0; i < states.length; i++) {
                if (states[i].equalsIgnoreCase(adminScope)) {
                    spinnerState.setSelection(i);
                    break;
                }
            }
            spinnerState.setEnabled(false); // Lock it
        } else {
            spinnerState.setEnabled(true); // India Govt can select any
        }

        // Date picker for DOB
        etDob.setOnClickListener(v -> {
            java.util.Calendar c = java.util.Calendar.getInstance();
            new android.app.DatePickerDialog(getContext(), (dp, year, month, day) -> {
                etDob.setText(year + "-" + String.format("%02d", (month + 1)) + "-" + String.format("%02d", day));
            }, c.get(java.util.Calendar.YEAR) - 20, c.get(java.util.Calendar.MONTH),
                    c.get(java.util.Calendar.DAY_OF_MONTH)).show();
        });

        builder.setPositiveButton("Add", (dialog, which) -> {
            String aadhaar = etAadhaar.getText().toString().trim();
            String name = etName.getText().toString().trim();
            String dob = etDob.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String mobile = etMobile.getText().toString().trim();
            String address = etAddress.getText().toString().trim();
            String city = etCity.getText().toString().trim();
            String state = spinnerState.getSelectedItem() != null ? spinnerState.getSelectedItem().toString() : "";
            String pincode = etPincode.getText().toString().trim();
            boolean isEligible = cbEligible.isChecked();

            // Validation
            if (aadhaar.isEmpty() || name.isEmpty() || dob.isEmpty()) {
                Toast.makeText(getContext(), "Aadhaar, Name, and DOB are required", Toast.LENGTH_SHORT).show();
                return;
            }

            if (aadhaar.length() != 12) {
                Toast.makeText(getContext(), "Aadhaar must be 12 digits", Toast.LENGTH_SHORT).show();
                return;
            }

            User newUser = new User(
                    aadhaar,
                    name,
                    dob,
                    email,
                    mobile,
                    "", // photo - empty for now
                    address,
                    city,
                    state,
                    pincode,
                    isEligible);

            userManager.addUser(newUser);
            loadUsers();
            Toast.makeText(getContext(), "User added successfully", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}
